package p1.lab2.info6205;

public class MotorBoat {

	private double capacity;
	private double amountInTank;		//amountInTank is the remaining fuel in tank
	private double maxSpeed;
	
	private double currSpeed;
	private double efficiency;
	private double distance;
	
	public MotorBoat() {
		
	}
	
	public MotorBoat(double capacity, double maxSpeed, double efficiency) {
		super();
		this.capacity = capacity;
		this.maxSpeed = maxSpeed;
		this.efficiency = efficiency;
	}

	public void changeSpeed(double s) {
		if(s>maxSpeed) {
			currSpeed = maxSpeed;
		}
		else {
			currSpeed = s;
		}
	}
	
	public void operateForTime(double time) {
		
		if (currSpeed == 0) {
            return;
        }
		
		double fuelUsed = efficiency * currSpeed *currSpeed *time;
		
		if(amountInTank >= fuelUsed) {
			amountInTank = amountInTank - fuelUsed;
			distance = distance + (currSpeed * time);
		}
		else {
			double operableTimeForBoat = amountInTank / (efficiency * currSpeed * currSpeed);
		//	System.out.println("New dist: "+ currSpeed * operableTimeForBoat );
			distance = distance + (currSpeed * operableTimeForBoat);
			amountInTank = 0;
		}
			
	}
	
	public void refuelBoat(double d) {
		if(d >= (capacity - amountInTank)) {
			amountInTank = capacity;
		}
		else {
			amountInTank = amountInTank + d;
		}
		
	}
	
	public double fuelRemaining() {
		
		return amountInTank;
	}
	
	public double distance() {
		
		return distance;
	}
}
