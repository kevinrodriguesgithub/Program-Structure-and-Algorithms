package p2.lab2.info6205;

public class ExaggeratingKid extends SchoolKid {
	
	public ExaggeratingKid() {
		
	}

	public ExaggeratingKid(String name, int age, String teacher, String greeting) {
		super(name, age, teacher, greeting);
	}
	
	@Override
	public int getAge() {
		return super.getAge() + 2;
	}
	
	@Override
	public String getGreeting() {
		return super.getGreeting() + " I am the best";
	}
	
	
}
