package p2.lab2.info6205;

public class SchoolKid {

	private String name;
	private int age;
	private String teacher;
	private String greeting;
	
	public SchoolKid() {
		
	}
	
	public SchoolKid(String name, int age, String teacher, String greeting) {
		super();
		this.name = name;
		this.age = age;
		this.teacher = teacher;
		this.greeting = greeting;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getTeacher() {
		return teacher;
	}
	public void changeTeacher(String teacher) {
		this.teacher = teacher;
	}
	
	public String getGreeting() {
		return greeting;
	}
	public void changeGreeting(String greeting) {
		this.greeting = greeting;
	}
	
	public int haveBirthday() {
		return age++;
	}

	@Override
	public String toString() {
		return "Base class data of school kid \n name:" + name + "\n age:" + age + "\n teacher:" + teacher + "\n greeting:" + greeting;
	}
		
}
