package p1.lab4.info6205;

import java.io.*;
import java.util.*;

/**
 * Hydra is a program that will simulate the work done for a
 * computational task that can be broken down into smaller subtasks.
 */

public class Hydra {

    public static void main(String args[]) {
    	ArrayBag<Integer> headBag = new ArrayBag<>(); 
    	ArrayBag<String> workBag = new ArrayBag<>();

        int startingSize;

        System.out.println("Please enter the size of the initial head.");
        startingSize = getInt("   It should be an integer value greater than or equal to 1.");

        // size of the headBag
        headBag.add(startingSize);

        System.out.println("The head bag is " + headBag);

        boolean noOverflow = true;

        // ADD CODE HERE TO DO THE SIMULATION
        
        // simulation steps
	    while (!headBag.isEmpty() && noOverflow) {
	    	
	        // Step 6: Call simulationStep in the main method
	        noOverflow = simulationStep(headBag, workBag);
	        
	        System.out.println();
	    }

        if (noOverflow) {
            System.out.println("The number of chops required is " + workBag.getCurrentSize());
        } else {
            System.out.println("Computation ended early with a bag overflow");
        }

    }

    /**
     * Take one head from the headBag bag.  If it is a final head, we are done with it.
     * Otherwise put in two heads that are one smaller.
     * Always put a chop into the work bag.
     *
     * @param  headBag   A bag holding the heads yet to be considered.
     * @param  workBag   A bag of chops.
     */

    public static boolean simulationStep(ArrayBag<Integer> heads, ArrayBag<String> work) {

    	// Size of the current head
        Integer currentHeadSize = heads.remove();

        boolean result = true;
        
        // If there's no head to process (currentHeadSize is null), we set result to false
        if (currentHeadSize == null) {
        	result = false;
            return result;
        }

        // Check if the head is a final head (larger than 1)
        if (currentHeadSize > 1) {
            // Add two smaller heads to the bag
            heads.add(currentHeadSize - 1);
            heads.add(currentHeadSize - 1);
        }

        // Check if either bag is full
        if (heads.isFull() || work.isFull()) {
        	result = false;
            return result; // Simulation cannot continue due to overflow
        }
        
        System.out.println("The head bag is now " + heads);

        // Add a chop to the work bag
        work.add("chop");

        // Display the current state of the work bag
        System.out.println("The work bag is now " + work);
        

        // Return true as the simulation step can continue
        return result;
    }

    /**
     * Get an integer value.
     * @return     An integer. 
     */
    private static int getInt(String rangePrompt) {
        Scanner input;
        int result = 10;        //default value is 10
        try {
            input = new Scanner(System.in);
            System.out.println(rangePrompt);
            result = input.nextInt();
        } catch (NumberFormatException e) {
            System.out.println("Could not convert input to an integer");
            System.out.println(e.getMessage());
            System.out.println("Will use 10 as the default value");
        } catch (Exception e) {
            System.out.println("There was an error with System.in");
            System.out.println(e.getMessage());
            System.out.println("Will use 10 as the default value");
        }
        return result;
    }
}
