package p2.lab4.info6205;

import java.util.ArrayList;

public class PileOfBooks<T> implements PileInterface<T> {
    private ArrayList<T> bookPile;

    public PileOfBooks() {
        bookPile = new ArrayList<>();
    }

    @Override
    public boolean isEmpty() {
        return bookPile.isEmpty();
    }

    @Override
    public void add(T book) {
        bookPile.add(book);
    }

    @Override
    public T remove() {
        if (isEmpty()) {
            return null;
        }
        return bookPile.remove(bookPile.size() - 1);
    }

    @Override
    public T getTopBook() {
        if (isEmpty()) {
            return null;
        }
        return bookPile.get(bookPile.size() - 1);
    }

    @Override
    public void clear() {
        bookPile.clear();
    }
}
