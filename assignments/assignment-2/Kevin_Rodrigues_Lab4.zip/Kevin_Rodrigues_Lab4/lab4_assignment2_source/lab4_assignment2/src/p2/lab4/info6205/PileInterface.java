package p2.lab4.info6205;

public interface PileInterface<T> {
    boolean isEmpty();
    void add(T book);
    T remove();
    T getTopBook();
    void clear();
}
