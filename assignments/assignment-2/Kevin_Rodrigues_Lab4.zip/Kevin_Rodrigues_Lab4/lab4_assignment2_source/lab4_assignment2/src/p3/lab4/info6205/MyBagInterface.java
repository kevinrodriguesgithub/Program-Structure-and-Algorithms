package p3.lab4.info6205;

import java.util.Iterator;

interface MyBagInterface<T> extends Iterable<T> {
    
	void add(T item);			// Adds an item to the Bag
    boolean remove(T item);		// Removes one occurrence of the item from the Bag and returns true if operation possible or does nothing and returns false
    boolean isEmpty();			// Returns true if the Bag is empty or false if not
    int size();					// Returns the number of items in the Bag
    
    Iterator<T> iterator();             						// Returns an iterator to iterate through the items in the Bag
    MyBagInterface<T> union(MyBagInterface<T> other);			// Returns the union of this Bag with another Bag
    MyBagInterface<T> intersection(MyBagInterface<T> other);	// Returns the intersection of this Bag with another Bag
    MyBagInterface<T> difference(MyBagInterface<T> other);		// Returns the difference between this Bag and another Bag

}


