package p3.lab4.info6205;

/* Implement MyBag concrete class in order to run this test */

public class MyBagTest {
    public static void main(String[] args) {
        
    	MyBagInterface<Integer> bag1 = new MyBag<>();
        MyBagInterface<Integer> bag2 = new MyBag<>();

        // Add elements to bag1
        bag1.add(1);
        bag1.add(2);
        bag1.add(2);
        bag1.add(3);

        // Add elements to bag2
        bag2.add(2);
        bag2.add(3);
        bag2.add(4);

        // Print the initial state of bag1 and bag2 (implement toString() in Bag concrete class)
        System.out.println("Bag 1: " + bag1);  // Bag 1: [1, 2, 2, 3] ORDER DOESNT MATTER
        System.out.println("Bag 2: " + bag2);  // Bag 2: [2, 3, 4] ORDER DOESNT MATTER

        // Perform Union
        MyBagInterface<Integer> unionBag = bag1.union(bag2);
        System.out.println("Union of Bag 1 and Bag 2: " + unionBag);  // Expected: [1, 2, 2, 3, 2, 3, 4]
                                                                      // ORDER DOESNT MATTER, element and frequencies MATTER
        // Perform Intersection
        MyBagInterface<Integer> intersectionBag = bag1.intersection(bag2);
        System.out.println("Intersection of Bag 1 and Bag 2: " + intersectionBag);  // Expected: [2, 3]
        																			// ORDER DOESNT MATTER, element and frequencies MATTER
        // Perform Difference 
        MyBagInterface<Integer> differenceBag = bag1.difference(bag2);
        System.out.println("Difference of Bag 1 and Bag 2: " + differenceBag);  // Expected: [1, 2]
                                                                                // ORDER DOESNT MATTER, element and frequencies MATTER
        // Remove an element from bag1
        bag1.remove(2);
        System.out.println("Bag 1 after removing 2: " + bag1);  // Expected: [1, 2, 3]
                                                                // ORDER DOESNT MATTER, element and frequencies MATTER
        // Check the size of bag1
        System.out.println("Bag 1 size: " + bag1.size());  // Expected: 3
                                                           
        // Check if bag1 is empty
        System.out.println("Bag 1 isEmpty: " + bag1.isEmpty());  // Expected: false
                                               
        // Clear bag1 and check if it is empty
        for(int i : bag1)bag1.remove(i);
        System.out.println("Bag 1 isEmpty after clear: " + bag1.isEmpty());  // Expected: true

        // Create a new bag for testing
        MyBagInterface<String> bag3 = new MyBag<>();
        bag3.add("apple");
        bag3.add("banana");
        bag3.add("apple");

        System.out.println("Bag 3: " + bag3);  // Expected: [apple, banana, apple]
                                               // ORDER DOESNT MATTER
        // Remove an element from bag3
        bag3.remove("apple");
        System.out.println("Bag 3 after removing 'apple': " + bag3);  // Expected: [banana, apple]
                                                                      // ORDER DOESNT MATTER
    }
}
