package p3.lab4.info6205;

import java.util.Iterator;
import java.util.*;

public class MyBag<T> implements MyBagInterface<T> {
	
	 private ArrayList<T> bagContents; 

	    public MyBag() {
	        bagContents = new ArrayList<>();
	    }
	
	@Override
	public void add(T item) {
		// ADD CODE HERE
		 bagContents.add(item);  
	}

	@Override
	public boolean remove(T item) {
		boolean removed = false;
	    Iterator<T> iterator = bagContents.iterator();
	    
	    // Iterate through the bag contents
	    while (iterator.hasNext()) {
	        if (iterator.next().equals(item)) {
	            iterator.remove(); 
	            removed = true;
	            break; 
	        }
	    }
	    return removed; 
	}

	@Override
	public boolean isEmpty() {
		return bagContents.isEmpty();
	}

	@Override
	public int size() {
		return bagContents.size(); 
	}

	@Override
	public Iterator<T> iterator() {
		return new Iterator<T>() {
	        private int currentIndex = 0;

	        @Override
	        public boolean hasNext() {
	            return currentIndex < bagContents.size();
	        }

	        @Override
	        public T next() {
	            if (hasNext()) {
	                return bagContents.get(currentIndex++);
	            } else {
	                throw new IllegalStateException("No more elements");
	            }
	        }

	        @Override
	        public void remove() {
	            if (currentIndex == 0) {
	                throw new IllegalStateException("Call next() before remove()");
	            }
	            bagContents.remove(--currentIndex);
	        }
	    }; 
	}

	@Override
	public MyBagInterface<T> union(MyBagInterface<T> other) {
		MyBag<T> result = new MyBag<>();  // Create a new bag to hold the union
	    result.bagContents.addAll(this.bagContents);  // Add all elements from the current bag
	    
	    for (T item : other) {
	        result.add(item);  // Add each element from the other bag as well
	    }

	    return result;
	}

	@Override
	public MyBagInterface<T> intersection(MyBagInterface<T> other) {
		MyBag<T> result = new MyBag<>();  // Create a new bag for the intersection
        ArrayList<T> otherContents = new ArrayList<>();
        for (T item : other) {
            otherContents.add(item);  // Copy items from the other bag into a list
        }

        for (T item : this.bagContents) {
            if (otherContents.contains(item)) {
                result.add(item);  // Add to result if the item exists in both bags
                otherContents.remove(item);  // Remove it to prevent duplicates
            }
        }
        return result;
	}

	@Override
	public MyBagInterface<T> difference(MyBagInterface<T> other) {
		MyBag<T> result = new MyBag<>();  // Create a new bag for the difference
        result.bagContents.addAll(this.bagContents);  // Add all elements from the current bag

        for (T item : other) {
            result.remove(item);  // Remove the items that are also in the other bag
        }
        return result;
	}
	
	public void clear() {
	    bagContents.clear();  // This will remove all elements from the internal list
	}
	
	public String toString() {
		return bagContents.toString(); 
	}
}
